import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';
import { ArtworkListComponent } from '../artwork-list/artwork-list.component';
import { LikedArtworksPage } from '../liked-artworks/liked-artworks.page';

const routes: Routes = [
  {
    path: '',
    component: TabsPage,
    children: [
      {
        path: 'home',
        loadChildren: () => import('../artwork-list/artwork-list.module').then(m => m.ArtworkListPageModule)
      },
      {
        path: 'likes',
        loadChildren: () => import('../liked-artworks/liked-artworks.module').then(m => m.LikedArtworksPageModule)
      },
      {
        path: 'information',
        loadChildren: () => import('../information/information.module').then(m => m.InformationPageModule)
      },
      {
        path: '',
        redirectTo: '/tabs/home',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TabsPageRoutingModule {}
