import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, catchError, Observable, of } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class PaintingService {
  getComments(id: number) {
    throw new Error('Method not implemented.');
  }
  private apiUrl = 'https://collectionapi.metmuseum.org/public/collection/v1/'; // for pintings and likes
  //private commentsUrl="https://us-central1-involvement-api.cloudfunctions.net/capstoneApi/apps/pKSoTbGzFhj5RtoeFQif/comments?item_id=451023"; // for comments
  //private likessUrl="https://us-central1-involvement-api.cloudfunctions.net/capstoneApi/apps/pKSoTbGzFhj5RtoeFQif/likes?item_id=451023";  // for likes
  private likedArtworks: Set<number> = new Set<number>(this.loadLikedArtworks());
  private likesSubject = new BehaviorSubject<Set<number>>(this.likedArtworks);

  constructor(private http: HttpClient) { }

  getArtworks(query: string): Observable<any> {
    return this.http.get(`${this.apiUrl}search?q=${query}&hasImages=true`);
  }

  getArtworkDetails(objectID: number): Observable<any> {
    return this.http.get(`${this.apiUrl}objects/${objectID}`);
  }

  toggleLike(objectID: number) {
    if (this.likedArtworks.has(objectID)) {
      this.likedArtworks.delete(objectID);
    } else {
      this.likedArtworks.add(objectID);
    }
    this.likesSubject.next(this.likedArtworks);
    this.saveLikedArtworks();
  }

  isLiked(objectID: number): boolean {
    return this.likedArtworks.has(objectID);
  }

  getLikedArtworks(): Observable<Set<number>> {
    return this.likesSubject.asObservable();
  }

// Fetch comments for a specific painting
 /*getCommentsForPainting(itemId: number): Observable<any[]> {
  const url = `${this.commentsUrl}?item_id=${itemId}`;
  return this.http.get<any[]>(url).pipe(
    catchError(error => {
      console.error('Error fetching comments:', error);
      return of([]); // Return an empty array in case of error
    })
  );
}*/

// Add comment for a specific painting
/*addComment(itemId: number, comment: { username: string; comment: string }): Observable<any> {
  const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  const body = { item_id: itemId, ...comment };
  return this.http.post<any>(this.commentsUrl, body, { headers }).pipe(
    catchError(error => {
      console.error('Error adding comment:', error);
      return of(null); // Return null in case of error
    })
  );
}*/

  // added to add comment to the API
  /*addComment(itemId: number, name: string, comment: string): Observable<any> {
    const url = this.commentsUrl;
    const body = {
      item_id: itemId,
      username: name,
      comment: comment
    };
    return this.http.post<any>(url, body).pipe(
      catchError(error => {
        console.error('Error adding comment:', error);
        return of(null);
      })
    );
  } */
    /*
    // Fetch painting details by ID ارجعي لها
    getArtworkById(id: string): Observable<any> {
      return this.http.get(`${this.commentsUrl}/paintings/${id}`);
    }
  
    // Fetch comments for a specific painting ارجعي لها
    getCommentsByPaintingId(id: string): Observable<any[]> {
      return this.http.get<any[]>(`${this.commentsUrl}/paintings/${id}/comments`);
    }
    */
  
  private saveLikedArtworks() {
    localStorage.setItem('likedArtworks', JSON.stringify(Array.from(this.likedArtworks)));
  }

  private loadLikedArtworks(): number[] {
    const storedLikedArtworks = localStorage.getItem('likedArtworks');
    return storedLikedArtworks ? JSON.parse(storedLikedArtworks) : [];
  }
}
