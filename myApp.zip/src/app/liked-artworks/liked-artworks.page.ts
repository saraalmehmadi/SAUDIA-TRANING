import { Component, OnInit, OnDestroy } from '@angular/core';
import { PaintingService } from '../paintingser/painting.service';
import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-liked-artworks',
  templateUrl: './liked-artworks.page.html',
  styleUrls: ['./liked-artworks.page.scss']
})
export class LikedArtworksPage implements OnInit, OnDestroy {
  likedArtworks: any[] = [];
  private likedArtworksSubscription: Subscription | undefined;

  constructor(private paintingService: PaintingService) { }

  ngOnInit() {
    // Subscribe to the liked artworks observable to get updates
    this.likedArtworksSubscription = this.paintingService.getLikedArtworks().subscribe(likedArtworksSet => {
      this.loadLikedArtworks(Array.from(likedArtworksSet));
    });
  }

  ngOnDestroy() {
    // Clean up the subscription
    if (this.likedArtworksSubscription) {
      this.likedArtworksSubscription.unsubscribe();
    }
  }

  loadLikedArtworks(likedArtworkIDs: number[]) {
    // Clear the current list before reloading
    this.likedArtworks = [];
    likedArtworkIDs.forEach(id => {
      this.paintingService.getArtworkDetails(id).subscribe(artwork => {
        if (artwork.primaryImageSmall && artwork.artistDisplayName) {
          this.likedArtworks.push(artwork);
        }
      });
    });
  }

  toggleLike(event: Event, objectID: number) {
    event.stopPropagation(); // Prevent navigation
    this.paintingService.toggleLike(objectID);
    // No need to manually filter the liked artworks here; the subscription will handle it
  }

  isLiked(objectID: number): boolean {
    return this.paintingService.isLiked(objectID);
  }
}
