
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { ArtworkDetailComponent } from './artwork-detail/artwork-detail.component'; // Add this if not added
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
   
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule, // Import ReactiveFormsModule here
    FormsModule
  ],
  providers: [{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }],
  bootstrap: [AppComponent]
})
export class AppModule {}




/*import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { ArtworkListComponent } from './artwork-list/artwork-list.component';
import { ArtworkDetailComponent } from './artwork-detail/artwork-detail.component';
import { PaintingService } from './paintingser/painting.service';
import { FormsModule } from '@angular/forms'; // Import FormsModule

@NgModule({
  declarations: [
    AppComponent,
    ArtworkListComponent,
    ArtworkDetailComponent
  ],
  imports: [
    BrowserModule,
    FormsModule, 
    IonicModule.forRoot(),
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', component: ArtworkListComponent },
      { path: 'artwork/:id', component: ArtworkDetailComponent }
    ])
  ],
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    PaintingService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
*/

/*import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { PaintingService } from './paintingser/painting.service';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule, 
    IonicModule.forRoot(),
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    PaintingService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }*/
/*
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { PaintingService } from './paintingser/painting.service';
import { FormsModule } from '@angular/forms';

// Import components
import { ArtworkListComponent } from './artwork-list/artwork-list.component';
import { ArtworkDetailComponent } from './artwork-detail/artwork-detail.component';
import { LikedArtworksPage } from './liked-artworks/liked-artworks.page'; // Add this import if necessary

@NgModule({
  declarations: [
    AppComponent,
    ArtworkListComponent, // Declare ArtworkListComponent
    ArtworkDetailComponent, // Declare ArtworkDetailComponent
    LikedArtworksPage // Add if it's used directly in app module
  ],
  imports: [
    BrowserModule,
    FormsModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    PaintingService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
*/