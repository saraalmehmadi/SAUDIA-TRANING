// هذا الصح
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PaintingService } from '../paintingser/painting.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-artwork-detail',
  templateUrl: './artwork-detail.component.html',
  styleUrls: ['./artwork-detail.component.scss']
})
export class ArtworkDetailComponent implements OnInit {
  artwork: any=null; // Replace `any` with a more specific type if available
  isLiked: boolean = false;
  comments: { name: string, comment: string, timestamp: Date }[] = [];
  newComment: { name: string, comment: string } = { name: '', comment: '' };
  showComments: boolean = false;
  commentForm: FormGroup;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private paintingService: PaintingService,
    private fb: FormBuilder
    
  ) { 
    this.commentForm = this.fb.group({
      name: ['', Validators.required],
      comment: ['', Validators.required]
    });
  }
 // add coments old method
 /*addComments() {
  if (this.newComment.name && this.newComment.comment) {
    const timestamp = new Date();
    this.comments.unshift({ ...this.newComment, timestamp });
    this.newComment.name = '';
    this.newComment.comment = '';
  }
}*/
//جربي احذفيها لان كررتها تحت
addComments() {
  if (this.newComment.name && this.newComment.comment) {
    const timestamp = new Date();
    this.comments.unshift({ ...this.newComment, timestamp });
    this.newComment.name = '';
    this.newComment.comment = '';
  }
}
  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.paintingService.getArtworkDetails(+id).subscribe(artwork => {
        this.artwork = artwork;
        this.isLiked = this.paintingService.isLiked(+id);
        //this.fetchComments(+id); // ADDED
      });
    } else {
      console.error('Invalid artwork ID');
    }
    
  }

  toggleLike() {
    if (this.artwork) {
      this.paintingService.toggleLike(this.artwork.objectID);
      this.isLiked = !this.isLiked; // Update local storage
    }
  }

  //ADDED
 /* fetchComments(id: number) {
    this.paintingService.getCommentsForPainting(id).subscribe(data => {
      this.comments = data.map((c: any) => ({
        username: c.username || 'Unknown',
        comment: c.comment,
        timestamp: new Date(c.timestamp)
      }));
    }, error => {
      console.error('Error fetching comments:', error);
    });
  }
//ADDED
  addComment() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (this.newComment.name && this.newComment.comment) {
      this.paintingService.addComment(id, this.newComment).subscribe(() => {
        this.fetchComments(id); // Refresh comments after adding a new one
        this.newComment = { username: '', comment: '' }; // Reset the form
      }, error => {
        console.error('Error adding comment:', error);
      });
    }
  } */

//جربي احذفيها لان كررتها تحت
  toggleComments() {
    this.showComments = !this.showComments;
  }
//جربي احذفيها لان كررتها تحت
  cancelComments() {
    this.showComments = false;
    this.newComment.name = '';
    this.newComment.comment = '';
  }

  goBack() {
    this.router.navigate(['/']);
  }

    // added to fetch comments
    /*fetchComments() {
      const id = this.route.snapshot.paramMap.get('id');
      if (id) {
        this.paintingService.getComments(+id).subscribe(fetchedComments => {
          this.comments = fetchedComments.map((c: any) => ({
            name: c.name || 'Unknown',
            comment: c.comment,
            timestamp: new Date(c.timestamp)
          }));
        });
      }
    }*/

} 

export class CommentsComponent {
  showComments = false;
  newComment = { name: '', comment: '' };
  comments: Array<{ name: string, comment: string, timestamp: Date }> = [];

  addComments() {
    if (this.newComment.name && this.newComment.comment) {
      const timestamp = new Date();
      this.comments.unshift({ ...this.newComment, timestamp });
      this.newComment.name = '';
      this.newComment.comment = '';
    }
  }

  toggleComments() {
    this.showComments = !this.showComments;
  }

  cancelComments() {
    this.showComments = false;
    this.newComment.name = '';
    this.newComment.comment = '';
  }
}