import { Component, OnInit } from '@angular/core';
import { PaintingService } from '../paintingser/painting.service';

@Component({
  selector: 'app-artwork-list',
  templateUrl: './artwork-list.component.html',
  styleUrls: ['./artwork-list.component.scss']
})
export class ArtworkListComponent implements OnInit {
  artworks: any[] = [];
  searchQuery: string = 'paintings'; // Define the search query here
  totalArtworks: number = 0; // Track total artworks
  isLoading: boolean = false;
 

  constructor(private paintingService: PaintingService) { }

  ngOnInit() {
    this.isLoading = true;
    this.paintingService.getArtworks('your-query-here').subscribe(response => {
      if (response.objectIDs) {
        this.loadArtworkDetails(response.objectIDs.slice(4, 35)); // Limit to 10 items for example
      }
      this.isLoading = false;
    });
  }

  loadArtworkDetails(objectIDs: number[]) {
    let validArtworksCount = 0;
    objectIDs.forEach(id => {
      this.paintingService.getArtworkDetails(id).subscribe(artwork => {
        if (artwork.primaryImageSmall) {
  
          // Unknown Artist 
          if (!artwork.artistDisplayName) {
            artwork.artistDisplayName = 'Unknown Artist';
          }
  
          this.artworks.push(artwork);
          validArtworksCount++;
          this.totalArtworks = validArtworksCount;
        }
      });
    });
  }


  toggleLike(event: Event, objectID: number) {
    event.stopPropagation(); // Prevent navigation
    this.paintingService.toggleLike(objectID);
  }

  isLiked(objectID: number): boolean {
    return this.paintingService.isLiked(objectID);
  }
}
